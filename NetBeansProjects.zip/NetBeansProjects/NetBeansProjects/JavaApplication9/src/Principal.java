/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class Principal {

    public static void main(String[] args) {

        Heroi batman = new Heroi();

        batman.setNome("Bruce Wayne");
        batman.setEnergia(100);
        batman.setVelocidade(50);
        batman.setVida(100);
        batman.setPoder("Inteligência");

        System.out.println("========== BATMAN ==========");
        batman.apresentar();
        System.out.println("Vida: " + batman.getVida());
        System.out.println("Energia: " + batman.getEnergia());
        System.out.println("Velocidade: " + batman.getVelocidade());
        System.out.println("Poder: " + batman.getPoder());

        Heroi superman = new Heroi();

        superman.setNome("Clark Kent");
        superman.setEnergia(100);
        superman.setVelocidade(100);
        superman.setVida(100);
        superman.setPoder("Super Força");

        System.out.println("\n========== SUPERMAN ==========");
        superman.apresentar();
        System.out.println("Vida: " + superman.getVida());
        System.out.println("Energia: " + superman.getEnergia());
        System.out.println("Velocidade: " + superman.getVelocidade());
        System.out.println("Poder: " + superman.getPoder());

        Guerreiro guerreiro = new Guerreiro();

        System.out.println("\n========== GUERREIRO ==========");
        guerreiro.apresentar();

        Mago mago = new Mago();

        System.out.println("\n========== MAGO ==========");
        mago.apresentar();

        Arqueiro arqueiro = new Arqueiro();

        System.out.println("\n========== ARQUEIRO ==========");
        arqueiro.apresentar();
    }
}