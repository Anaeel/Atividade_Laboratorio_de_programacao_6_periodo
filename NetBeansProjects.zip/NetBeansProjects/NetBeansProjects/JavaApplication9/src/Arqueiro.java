/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class Arqueiro extends Heroi {

    public Arqueiro() {
        setNome("Arqueiro");
        setVida(120);
        setEnergia(120);
        setVelocidade(100);
        setPoder("Arco e Flecha");
    }

    @Override
    public void apresentar() {
        System.out.println("Sou o " + getNome());
        System.out.println("Vida: " + getVida());
        System.out.println("Energia: " + getEnergia());
        System.out.println("Velocidade: " + getVelocidade());
        System.out.println("Poder: " + getPoder());
        System.out.println("Ataco usando meu arco!");
    }
}