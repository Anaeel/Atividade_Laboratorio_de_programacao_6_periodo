/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class Guerreiro extends Heroi {

    public Guerreiro() {
        setNome("Guerreiro");
        setVida(150);
        setEnergia(100);
        setVelocidade(50);
        setPoder("Espada");
    }

    @Override
    public void apresentar() {
        System.out.println("Sou o " + getNome());
        System.out.println("Vida: " + getVida());
        System.out.println("Energia: " + getEnergia());
        System.out.println("Velocidade: " + getVelocidade());
        System.out.println("Poder: " + getPoder());
        System.out.println("Ataco usando minha espada!");
    }
}