/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class Mago extends Heroi {

    public Mago() {
        setNome("Mago");
        setVida(100);
        setEnergia(200);
        setVelocidade(40);
        setPoder("Magia");
    }

    @Override
    public void apresentar() {
        System.out.println("Sou o " + getNome());
        System.out.println("Vida: " + getVida());
        System.out.println("Energia: " + getEnergia());
        System.out.println("Velocidade: " + getVelocidade());
        System.out.println("Poder: " + getPoder());
        System.out.println("Ataco usando magia!");
    }
}